import 'package:flutter/material.dart';

class AppColors {
  static const Color background = Color(0xFF0B132B);
  static const Color activeCard = Color(0xFF1C2541);
  static const Color inactiveCard = Color(0xFF121A2E);
  static const Color primaryTeal = Color(0xFF5BC0BE);
  static const Color textPrimary = Color(0xFFFFFFFF);
  static const Color textSecondary = Color(0xFFB8C5D6);
  static const Color buttonCircle = Color(0xFF17223C);
}
