import 'package:flutter/material.dart';

import '../contants/app_colors.dart';
import '../utils/water_calculator.dart';
import '../widgets/conter_card.dart';
import '../widgets/gender_card.dart';
import '../widgets/bottom_button.dart';
import 'result_screen.dart';

enum Gender { male, female }

class InputScreen extends StatefulWidget {
  const InputScreen({super.key});

  @override
  State<InputScreen> createState() => _InputScreenState();
}

class _InputScreenState extends State<InputScreen> {
  // الحدود المسموحة حسب التكليف
  static const int minWeight = 30;
  static const int maxWeight = 200;
  static const int minAge = 10;
  static const int maxAge = 100;
  static const double minActivity = 0.0;
  static const double maxActivity = 8.0;

  // القيم الافتراضية المطابقة للصورة
  Gender? chosenGender = Gender.male;
  double dailyActivityHours = 2.0;
  int bodyWeightKg = 70;
  int userAgeYears = 25;

  void _resetInputs() {
    setState(() {
      chosenGender = Gender.male;
      dailyActivityHours = 2.0;
      bodyWeightKg = 70;
      userAgeYears = 25;
    });
  }

  void _calculateAndNavigate() {
    if (chosenGender == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Please select a gender first.'),
          backgroundColor: Colors.redAccent,
        ),
      );
      return;
    }

    if (bodyWeightKg < minWeight ||
        bodyWeightKg > maxWeight ||
        userAgeYears < minAge ||
        userAgeYears > maxAge ||
        dailyActivityHours < minActivity ||
        dailyActivityHours > maxActivity) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Please enter valid values within the allowed range.'),
          backgroundColor: Colors.redAccent,
        ),
      );
      return;
    }

    final double recommendedLitres = WaterCalculator.calculateWaterLitres(
      bodyWeightKg: bodyWeightKg,
      dailyActivityHours: dailyActivityHours,
    );

    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => ResultScreen(
          recommendedLitres: recommendedLitres,
          bodyWeightKg: bodyWeightKg,
          userAgeYears: userAgeYears,
          dailyActivityHours: dailyActivityHours,
          gender: chosenGender == Gender.male ? 'Male' : 'Female',
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              // زر Reset صغير في الأعلى (تحدي إضافي)
              Align(
                alignment: Alignment.centerRight,
                child: IconButton(
                  tooltip: 'Reset to defaults',
                  onPressed: _resetInputs,
                  icon: const Icon(
                    Icons.refresh_rounded,
                    color: AppColors.textSecondary,
                    size: 22,
                  ),
                ),
              ),

              // 1. رأس الصفحة مطابق للصورة
              Column(
                children: [
                  Container(
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: AppColors.primaryTeal.withOpacity(0.12),
                    ),
                    child: const Icon(
                      Icons.water_drop,
                      color: AppColors.primaryTeal,
                      size: 46,
                    ),
                  ),
                  const SizedBox(height: 12),
                  const Text(
                    'Daily Water',
                    style: TextStyle(
                      color: AppColors.textPrimary,
                      fontSize: 28,
                      fontWeight: FontWeight.bold,
                      height: 1.1,
                    ),
                  ),
                  const Text(
                    '& Hydration Tracker',
                    style: TextStyle(
                      color: AppColors.primaryTeal,
                      fontSize: 20,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  const SizedBox(height: 6),
                  const Text(
                    'Stay hydrated. Stay healthy.',
                    style: TextStyle(
                      color: AppColors.textSecondary,
                      fontSize: 13,
                    ),
                  ),
                ],
              ),

              const SizedBox(height: 24),

              // 2. قسم اختيار الجنس
              const Row(
                children: [
                  Icon(Icons.person, color: AppColors.textSecondary, size: 18),
                  SizedBox(width: 8),
                  Text(
                    'Gender',
                    style: TextStyle(
                      color: AppColors.textPrimary,
                      fontSize: 15,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 10),
              Row(
                children: [
                  Expanded(
                    child: GenderCard(
                      label: 'Male',
                      icon: Icons.male,
                      isSelected: chosenGender == Gender.male,
                      onTap: () => setState(() => chosenGender = Gender.male),
                    ),
                  ),
                  const SizedBox(width: 14),
                  Expanded(
                    child: GenderCard(
                      label: 'Female',
                      icon: Icons.female,
                      isSelected: chosenGender == Gender.female,
                      onTap: () => setState(() => chosenGender = Gender.female),
                    ),
                  ),
                ],
              ),

              const SizedBox(height: 22),

              // 3. قسم ساعات النشاط البدني
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const Row(
                    children: [
                      Icon(
                        Icons.directions_run,
                        color: AppColors.textSecondary,
                        size: 19,
                      ),
                      SizedBox(width: 8),
                      Text(
                        'Activity Hours',
                        style: TextStyle(
                          color: AppColors.textPrimary,
                          fontSize: 15,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                    ],
                  ),
                  Text(
                    '${dailyActivityHours % 1 == 0 ? dailyActivityHours.toInt() : dailyActivityHours.toStringAsFixed(1)} h',
                    style: const TextStyle(
                      color: AppColors.primaryTeal,
                      fontSize: 15,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 4),
              SliderTheme(
                data: SliderTheme.of(context).copyWith(
                  activeTrackColor: AppColors.primaryTeal,
                  inactiveTrackColor: AppColors.activeCard,
                  thumbColor: AppColors.primaryTeal,
                  overlayColor: AppColors.primaryTeal.withOpacity(0.2),
                  trackHeight: 4.5,
                  thumbShape: const RoundSliderThumbShape(
                    enabledThumbRadius: 9,
                  ),
                ),
                child: Slider(
                  value: dailyActivityHours,
                  min: minActivity,
                  max: maxActivity,
                  divisions: 16, // خطوة كل نصف ساعة (0.5)
                  onChanged: (double newValue) {
                    setState(() {
                      dailyActivityHours = newValue;
                    });
                  },
                ),
              ),
              const Padding(
                padding: EdgeInsets.symmetric(horizontal: 10),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      '0',
                      style: TextStyle(
                        color: AppColors.textSecondary,
                        fontSize: 12,
                      ),
                    ),
                    Text(
                      '8',
                      style: TextStyle(
                        color: AppColors.textSecondary,
                        fontSize: 12,
                      ),
                    ),
                  ],
                ),
              ),

              const SizedBox(height: 18),

              // 4. بطاقة الوزن
              CounterCard(
                title: 'Weight',
                unit: 'kg',
                icon: Icons.monitor_weight_outlined,
                value: bodyWeightKg,
                onDecrement: () {
                  if (bodyWeightKg > minWeight) {
                    setState(() => bodyWeightKg--);
                  }
                },
                onIncrement: () {
                  if (bodyWeightKg < maxWeight) {
                    setState(() => bodyWeightKg++);
                  }
                },
              ),

              const SizedBox(height: 14),

              // 5. بطاقة العمر
              CounterCard(
                title: 'Age',
                unit: 'years',
                icon: Icons.calendar_today_outlined,
                value: userAgeYears,
                onDecrement: () {
                  if (userAgeYears > minAge) {
                    setState(() => userAgeYears--);
                  }
                },
                onIncrement: () {
                  if (userAgeYears < maxAge) {
                    setState(() => userAgeYears++);
                  }
                },
              ),

              const SizedBox(height: 24),

              // 6. زر الحساب السفلي
              BottomButton(
                label: 'Calculate Water Intake',
                leadingIcon: Icons.calculate_outlined,
                trailingIcon: Icons.arrow_forward,
                onTap: _calculateAndNavigate,
              ),
            ],
          ),
        ),
      ),
    );
  }
}
